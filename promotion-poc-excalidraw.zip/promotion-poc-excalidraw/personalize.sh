#!/usr/bin/env bash
# Remplace les placeholders __XXX__ dans les deux stacks.
# Usage : exporte les variables (ou édite les valeurs par défaut), puis ./personalize.sh
set -euo pipefail

# --- Commun ---------------------------------------------------------------
: "${GITOPS_REPO:=https://dev.azure.com/MON-ORG/MON-PROJET/_git/promotion-poc-excalidraw}" # Azure Repos, HTTPS, SANS "org@"
: "${GITOPS_REPO_SSH:=git@ssh.dev.azure.com:v3/MON-ORG/MON-PROJET/promotion-poc-excalidraw}" # SSH (piped PipeCD)
: "${IMAGE_REPO:=monacr.azurecr.io/excalidraw}"       # registre des versions d'Excalidraw (ACR, Harbor...)
: "${DOMAIN:=apps.mon-cluster.example.com}"           # OPTIONNEL : seulement si tu actives l'Ingress
: "${INGRESS_CLASS:=nginx}"                           # OPTIONNEL : nginx (RKE2) ou traefik

# --- Stack Kargo ----------------------------------------------------------
: "${ARGOCD_NS:=argocd}"
: "${DEST_SERVER:=https://kubernetes.default.svc}"    # cluster des namespaces dev/staging/prod (défaut : celui d'Argo CD)
: "${RANCHER_PROJECT_ID:=c-xxxxx:p-xxxxx}"            # OPTIONNEL : projet Rancher des namespaces (annotation commentée)
: "${GIT_USERNAME:=kargo}"                             # ignoré par Azure DevOps avec un PAT
: "${GIT_TOKEN:=CHANGE-ME}"                           # PAT Azure DevOps, scope "Code: Read & write"
: "${GROUP_DEVS:=excalidraw-devs}"                    # groupe OIDC développeurs
: "${GROUP_RELEASE:=excalidraw-release-managers}"     # groupe OIDC release managers

# --- Stack PipeCD ---------------------------------------------------------
: "${PIPED_IMAGE:=ghcr.io/mon-org/piped-poc:v0.58.0}" # image piped enrichie (pipectl + trivy)
: "${PIPECD_APPROVER_1:=hello-pipecd}"                # utilisateur autorisé à approuver la prod

cd "$(dirname "$0")"

case "$GITOPS_REPO" in
  https://*@dev.azure.com/*)
    echo "GITOPS_REPO contient 'org@' : retire-le (format attendu https://dev.azure.com/<org>/<projet>/_git/<depot>)"; exit 1 ;;
esac

files=$(grep -rlE '__[A-Z0-9_]+__' app stack-kargo stack-pipecd shared 2>/dev/null || true)
for f in $files; do
  sed -i.bak \
    -e "s#__GITOPS_REPO_SSH__#${GITOPS_REPO_SSH}#g" \
    -e "s#__GITOPS_REPO__#${GITOPS_REPO}#g" \
    -e "s#__IMAGE_REPO__#${IMAGE_REPO}#g" \
    -e "s#__DOMAIN__#${DOMAIN}#g" \
    -e "s#__INGRESS_CLASS__#${INGRESS_CLASS}#g" \
    -e "s#__ARGOCD_NS__#${ARGOCD_NS}#g" \
    -e "s#__DEST_SERVER__#${DEST_SERVER}#g" \
    -e "s#__RANCHER_PROJECT_ID__#${RANCHER_PROJECT_ID}#g" \
    -e "s#__GIT_USERNAME__#${GIT_USERNAME}#g" \
    -e "s#__GIT_TOKEN__#${GIT_TOKEN}#g" \
    -e "s#__GROUP_DEVS__#${GROUP_DEVS}#g" \
    -e "s#__GROUP_RELEASE__#${GROUP_RELEASE}#g" \
    -e "s#__PIPED_IMAGE__#${PIPED_IMAGE}#g" \
    -e "s#__PIPECD_APPROVER_1__#${PIPECD_APPROVER_1}#g" \
    "$f"
  rm -f "$f.bak"
done

echo "Placeholders restants (seul __PIPED_ID__ est attendu, rempli à l'installation de piped) :"
grep -rnE '__[A-Z0-9_]+__' app stack-kargo stack-pipecd shared | grep -v '__PIPED_ID__' || echo "  aucun ✔"
echo
echo "Secrets (exclus de Git par .gitignore) :"
echo "  stack-kargo/secrets/kargo-git-credentials.yaml  (contient maintenant ton token)"
echo "  stack-pipecd/secrets/{piped-key,api-key,ssh-key} (à créer, cf. stack-pipecd/README.md)"
