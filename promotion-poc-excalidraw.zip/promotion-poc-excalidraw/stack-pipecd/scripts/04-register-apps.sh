#!/usr/bin/env bash
# Enregistre les 3 applications dans PipeCD.
# Alternative sans CLI : UI > Applications > +ADD > "ADD FROM SUGGESTIONS"
# (piped "poc", plateforme kubernetes-default) et choisir les 3 apps excalidraw-*.
set -euo pipefail
cd "$(dirname "$0")/.."

: "${PIPED_ID:?Exporte PIPED_ID}"
API_KEY="$(cat secrets/api-key)"
ADDRESS="${PIPECD_ADDRESS:-localhost:8080}"   # via kubectl port-forward -n pipecd svc/pipecd 8080

for env in dev staging prod; do
  pipectl application add \
    --address="$ADDRESS" --insecure --api-key="$API_KEY" \
    --app-name="excalidraw-${env}" \
    --app-kind=KUBERNETES \
    --piped-id="$PIPED_ID" \
    --platform-provider=kubernetes-default \
    --repo-id=poc \
    --app-dir="stack-pipecd/apps/excalidraw-${env}" \
    --config-file-name=app.pipecd.yaml \
    --description="POC promotion Excalidraw (${env})"
done
echo "Applications enregistrées. Le 1er déploiement synchronise l'état du dépôt (tag 1.0.0)."
