#!/usr/bin/env bash
# Control plane PipeCD en mode "quickstart" (POC uniquement) :
# projet fixe "quickstart", utilisateur statique hello-pipecd / hello-pipecd,
# pas de TLS. Pour un usage réel : installation Helm + SSO (voir la doc).
#
# À installer sur un cluster SÉPARÉ de la stack Kargo, ou au moins dans des
# namespaces distincts (c'est le cas : pipecd, pcd-excalidraw-*).
set -euo pipefail

PIPECD_REF="${PIPECD_REF:-v0.58.0}"   # tag Git du dépôt pipe-cd/pipecd ; "master" en secours

kubectl create namespace pipecd --dry-run=client -o yaml | kubectl apply -f -
kubectl apply -n pipecd \
  -f "https://raw.githubusercontent.com/pipe-cd/pipecd/${PIPECD_REF}/quickstart/manifests/control-plane.yaml"

kubectl -n pipecd wait --for=condition=available deploy --all --timeout=10m

cat <<'EOF'

Control plane prêt.
  kubectl port-forward -n pipecd svc/pipecd 8080
  -> http://localhost:8080?project=quickstart   (hello-pipecd / hello-pipecd)

Étapes manuelles dans l'UI (2 min) :
  1. Settings > Piped > +ADD, nom "poc"  -> note le Piped ID (UUID) et la clé
     -> enregistre la clé DÉCODÉE du base64 dans stack-pipecd/secrets/piped-key
  2. Settings > API Keys > +ADD, rôle READ_WRITE
     -> enregistre la clé dans stack-pipecd/secrets/api-key
  3. Crée une clé SSH de déploiement avec droit d'écriture sur le dépôt GitOps
     -> clé privée dans stack-pipecd/secrets/ssh-key
EOF
