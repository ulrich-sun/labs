#!/usr/bin/env bash
# Déploie piped avec la configuration de la POC.
# Prérequis (cf. 01-install-controlplane.sh) :
#   secrets/piped-key  : clé du piped (décodée)
#   secrets/api-key    : clé API READ_WRITE (pour publier les événements)
#   secrets/ssh-key    : clé SSH avec droit d'écriture sur le dépôt GitOps
#   PIPED_ID           : UUID du piped, exporté dans l'environnement
set -euo pipefail
cd "$(dirname "$0")/.."

: "${PIPED_ID:?Exporte PIPED_ID (UUID affiché dans Settings > Piped)}"
for f in piped-key api-key ssh-key; do
  [[ -s "secrets/$f" ]] || { echo "Fichier manquant : stack-pipecd/secrets/$f"; exit 1; }
done

kubectl -n pipecd create secret generic piped \
  --from-file=piped-key=secrets/piped-key \
  --from-file=api-key=secrets/api-key \
  --from-file=ssh-key=secrets/ssh-key \
  --dry-run=client -o yaml | kubectl apply -f -

sed "s#__PIPED_ID__#${PIPED_ID}#g" piped/piped.yaml | kubectl apply -f -
kubectl -n pipecd rollout status deploy/piped --timeout=5m
echo "Piped connecté : vérifie qu'il apparaît 'Online' dans Settings > Piped."
