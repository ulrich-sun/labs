#!/usr/bin/env bash
# Simule une release côté PipeCD :
#   1. publie l'image versionnée dans le registre (script partagé) ;
#   2. annonce la version à PipeCD (événement "excalidraw-dev-image").
# La suite est automatique : dev -> (tests) -> staging -> (tests, trivy, 10 min)
# -> PR vers prod -> merge -> approbation -> prod.
#
# Usage : ./stack-pipecd/scripts/release.sh 1.1.0 [--broken]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"

VERSION="${1:?Usage: $0 <x.y.z> [--broken]}"
"$ROOT/shared/scripts/publish-image.sh" "$VERSION" "${2:-}"

pipectl event register \
  --address="${PIPECD_ADDRESS:-localhost:8080}" --insecure \
  --api-key="$(cat "$ROOT/stack-pipecd/secrets/api-key")" \
  --name=excalidraw-dev-image \
  --data="$VERSION"

echo "Événement publié. Suis le déploiement : http://localhost:8080/deployments?project=quickstart"
