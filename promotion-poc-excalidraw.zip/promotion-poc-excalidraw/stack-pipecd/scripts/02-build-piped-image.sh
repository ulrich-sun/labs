#!/usr/bin/env bash
# Construit et pousse l'image piped enrichie (pipectl + trivy).
set -euo pipefail
cd "$(dirname "$0")/.."

PIPED_IMAGE="${PIPED_IMAGE:-__PIPED_IMAGE__}"

docker build --platform linux/amd64 -t "$PIPED_IMAGE" piped/
docker push "$PIPED_IMAGE"
echo "Image poussée : $PIPED_IMAGE"
