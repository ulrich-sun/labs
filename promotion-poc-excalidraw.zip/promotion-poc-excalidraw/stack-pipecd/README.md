# Stack B — PipeCD v0.58 (remplace Argo CD pour cette application)

Même scénario de promotion **dev → staging → prod** d'Excalidraw, avec PipeCD seul :
il déploie lui-même (agent `piped`), approbation et scripts sont **natifs et gratuits**.

> **Pourquoi la v0.58 et pas la v1 ?** La v1 (architecture à plugins) est encore en pré-version
> (images `pipedv1-exp`, tags alpha/RC). La v0.58 est la version stable : stages `WAIT_APPROVAL`,
> `SCRIPT_RUN`, `WAIT`, event watcher et rollback automatique y sont disponibles.
> `SCRIPT_RUN` y est marqué « alpha » par PipeCD.

| Rôle | Composant |
|---|---|
| Control plane (UI, API, approbations) | PipeCD control plane (mode quickstart pour la POC) |
| Déploiement | `piped` (image enrichie de `pipectl` + `trivy`) |
| Promotion entre environnements | Event watcher : chaque pipeline réussi publie l'événement de l'environnement suivant |

```
release.sh ──► événement excalidraw-dev-image ──► commit du tag ──► pipeline DEV
   DEV     : déploiement ─► smoke test ─► publie excalidraw-staging-image
   STAGING : déploiement ─► smoke test ─► Trivy ─► WAIT 10 min ─► publie excalidraw-prod-image
   PROD    : PULL REQUEST (à merger) ─► WAIT_APPROVAL (UI PipeCD) ─► déploiement ─► smoke test
   tout échec ─► rollback automatique de l'environnement concerné
```

## Arborescence

| Chemin | Rôle |
|---|---|
| `apps/excalidraw-<env>/` | `app.pipecd.yaml` (pipeline + event watcher) et `kustomization.yaml` (tag courant) |
| `piped/Dockerfile` | Image piped + `pipectl` + `trivy` |
| `piped/piped.yaml` | Déploiement de piped et sa configuration |
| `secrets/` | `piped-key`, `api-key`, `ssh-key` (hors Git) |
| `scripts/` | Installation et release |

## Mise en route

Idéalement sur un cluster distinct de la stack Kargo ; sinon les namespaces `pcd-*` évitent les collisions.

```bash
./personalize.sh                                   # à la racine
./shared/scripts/bootstrap-repo.sh                 # si pas déjà fait

./stack-pipecd/scripts/01-install-controlplane.sh  # puis étapes UI : piped, clé API, clé SSH
./stack-pipecd/scripts/02-build-piped-image.sh
export PIPED_ID=<uuid>
./stack-pipecd/scripts/03-install-piped.sh
kubectl port-forward -n pipecd svc/pipecd 8080 &
./stack-pipecd/scripts/04-register-apps.sh         # ou via l'UI "ADD FROM SUGGESTIONS"

./stack-pipecd/scripts/release.sh 1.1.0
```

## Scénarios de démo

1. **Flux nominal** — `release.sh 1.1.0` : dev puis staging se déploient et se testent seuls ; après 10 min une PR apparaît pour la prod.
2. **Double verrou prod** — merger la PR : le pipeline prod démarre et **s'arrête** sur `WAIT_APPROVAL` ; cliquer *Approve* dans l'UI (utilisateur listé dans `approvers`).
3. **Version cassée** — `release.sh 1.2.0 --broken` : le smoke test dev échoue, rollback automatique, staging n'est jamais touché.
4. **Refus** — ne pas approuver : au bout de 8 h (`timeout`) le déploiement prod échoue, rien ne change.
5. **Traçabilité** — page Deployments : qui a approuvé, quand, quel commit.

## Limites connues

- PipeCD **remplace** Argo CD pour les applications qu'il gère : pas de cohabitation sur la même app.
- Pas d'objet « version qui traverse les environnements » : la promotion est construite par chaînage d'événements, à maintenir soi-même.
- `approvers` attend des identifiants d'utilisateurs (logins SSO) ; quorum via `minApproverNum`.
- Le mode quickstart (utilisateur statique, pas de TLS) n'est pas exploitable en production.
- Le canary natif (`K8S_CANARY_ROLLOUT`) est possible mais demande un label de variante dans le sélecteur dès le premier déploiement : laissé en extension.
- Commandes `pipectl` (`event register`, `application add`) et flags à confirmer avec `pipectl --help` sur ta version.
