#!/usr/bin/env bash
# Initialise le dépôt GitOps commun aux deux stacks :
#  - pousse ce dossier sur main (les secrets sont exclus par .gitignore) ;
#  - crée les branches stage/dev, stage/staging, stage/prod utilisées par Kargo
#    (historique vide, sans toucher au répertoire de travail).
# À lancer à la racine du dépôt cloné, APRÈS personalize.sh.
set -euo pipefail

git checkout -B main
git add -A
git status --short | grep -E 'secrets/' && { echo "Des secrets seraient commités : abandon."; exit 1; } || true
git commit -m "POC promotion Excalidraw : bootstrap" || true
git push -u origin main

for stage in dev staging prod; do
  if git ls-remote --exit-code --heads origin "stage/${stage}" >/dev/null; then
    echo "stage/${stage} existe déjà"; continue
  fi
  blob=$(printf '# Manifests rendus par Kargo pour le stage %s — ne pas éditer à la main\n' "$stage" \
         | git hash-object -w --stdin)
  tree=$(printf '100644 blob %s\tREADME.md\n' "$blob" | git mktree)
  commit=$(git commit-tree "$tree" -m "init stage/${stage}")
  git push origin "${commit}:refs/heads/stage/${stage}"
  echo "stage/${stage} créée ✔"
done

echo "Azure DevOps : Repos > Branches > stage/prod > Branch policies"
echo "  -> 'Require a minimum number of reviewers' (ex. 1) pour que la PR de prod soit une vraie approbation."
