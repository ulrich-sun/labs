#!/usr/bin/env bash
# Publie une "release" d'Excalidraw dans TON registre sous un tag SemVer.
#  - Stack Kargo  : le Warehouse détecte le nouveau tag tout seul.
#  - Stack PipeCD : utiliser stack-pipecd/scripts/release.sh, qui appelle ce
#                   script PUIS annonce la version à PipeCD.
#
# Usage :
#   ./shared/scripts/publish-image.sh 1.1.0
#   ./shared/scripts/publish-image.sh 1.2.0 --broken   # version cassée (CrashLoop)
#
# Prérequis : crane (go-containerregistry) + login sur le registre.
set -euo pipefail

VERSION="${1:?Usage: $0 <x.y.z> [--broken]}"
IMAGE_REPO="${IMAGE_REPO:-__IMAGE_REPO__}"
SOURCE_IMAGE="${SOURCE_IMAGE:-excalidraw/excalidraw:latest}"

if [[ "${2:-}" == "--broken" ]]; then
  # busybox sans commande -> le conteneur s'arrête aussitôt -> CrashLoopBackOff
  SOURCE_IMAGE="busybox:1.36"
  echo "⚠️  Publication d'une version volontairement CASSÉE"
fi

crane copy "$SOURCE_IMAGE" "${IMAGE_REPO}:${VERSION}"
echo "Publié : ${IMAGE_REPO}:${VERSION}"
