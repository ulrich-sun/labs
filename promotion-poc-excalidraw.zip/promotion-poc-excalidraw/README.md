# POC promotion d'environnements — Excalidraw

Deux stacks **open source, sans licence**, qui réalisent le même scénario de promotion
dev → staging → prod d'Excalidraw, pour comparer les approches.

**Environnements = namespaces d'un même cluster** : `excalidraw-dev|staging|prod` (stack Kargo),
`pcd-excalidraw-dev|staging|prod` (stack PipeCD). Pas de DNS ni d'Ingress requis : l'Ingress est
un composant optionnel (`app/components/ingress`).

| | **Stack A — Kargo** (`stack-kargo/`) | **Stack B — PipeCD** (`stack-pipecd/`) |
|---|---|---|
| Garde Argo CD | Oui, Kargo le pilote | Non, PipeCD déploie lui-même |
| Promotion entre environnements | Native (Freight, Stages, vérification amont obligatoire) | Construite : chaînage d'événements entre 3 applications |
| Approbation humaine | Argo Workflows (`suspend`), déclenché par Kargo | `WAIT_APPROVAL` natif dans l'UI PipeCD |
| Étapes custom (conteneurs, scripts) | Workflow Argo (conteneurs arbitraires, en parallèle) | `SCRIPT_RUN` dans le conteneur piped |
| Approbation par PR | Option (`render-pr-and-sync`) | Oui (`makePullRequest` sur la prod) |
| Rollback automatique | Oui (`autoRollback` du ProjectConfig) | Oui (`autoRollback` de l'app) |
| RBAC par environnement | Verbe `promote` par Stage + groupes OIDC | Liste `approvers` par application |
| Fenêtres de promotion | Oui | Non |
| Soak time | Oui (`requiredSoakTime`) | Approché par un stage `WAIT` |
| Interfaces à suivre | 2 (Kargo + Argo Workflows) | 1 (PipeCD) |

## Contenu

```
app/base/           Manifests Excalidraw communs (Deployment, Service)
app/components/     Ingress optionnel
shared/scripts/     publish-image.sh (simule une release), bootstrap-repo.sh
stack-kargo/        Stack A — runbook de commandes : stack-kargo/README.md
stack-pipecd/       Stack B — voir stack-pipecd/README.md
personalize.sh      Remplace les placeholders (__DOMAIN__, __IMAGE_REPO__…)
```

## Démarrage

1. Exporter les variables décrites en tête de `personalize.sh`, puis `./personalize.sh`.
2. Pousser ce dossier dans un dépôt Git vide : `./shared/scripts/bootstrap-repo.sh`.
3. Suivre le README de chaque stack. Les deux peuvent tourner en parallèle (namespaces distincts :
   `excalidraw-*` pour Kargo, `pcd-excalidraw-*` pour PipeCD).

Les secrets (`stack-*/secrets/`) sont exclus de Git par `.gitignore`.
